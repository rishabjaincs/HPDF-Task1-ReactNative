/*
 Rishab Jain
*/

import React,{Component} from 'react';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import {
  Button,
  ScrollView,
  Platform,
  StyleSheet,
  Text,
  Image,
  View
} from 'react-native';
import { Container, Header, Left, Body, Right, Title } from 'native-base';
import SearchBar from 'react-native-searchbar';

import {TabNavigator,DrawerNavigator} from 'react-navigation';
import first from './screen/first';
import second from './screen/second';
import third from './screen/third';
import four from './screen/four';
import five from './screen/five';
import six from './screen/six';
import tab1 from './screen/tab1';
import tab2 from './screen/tab2';
const MainScreenNavigator= TabNavigator({
    tab1:{screen:tab1},
    tab2:{screen:tab2}
  },{
    tabBarPosition:'top',
    swipeEnabled:true,
    tabBarOptions:{
      activeTintColor:'white',
      activeBackgroundColor:'gray',
      inactiveTintColor:'blue',
      inactiveBackgroundColor:'green',
      labelStyle:{
        fontSize:16,
        padding:0}

      }
    }
  );
  MainScreenNavigator.navigationOptions={
    title: "Moments",
    tabBarLabel: 'Screen 1',
    drawerIcon: ({tintColor})=> {
      return (

        <MaterialIcons
        name="card-membership"
        size={24}
        style={{color: tintColor}}
        >
        </MaterialIcons>
        );
    }
  };

class MyHomeScreen extends Component {
  render(){
    return(
      

<View style={{ flex: 1, marginTop: 0 }}>
    
    <SearchBar
    ref={(ref) => this.searchBar = ref}
          showOnLoad
          placeholder='Search Twitter'/>

    <View style={
      {
      flex: 3,
      justifyContent: 'center',
      alignItems: 'center'
      }
    }>

    <Image 
style={{width: 120, height: 120, marginTop:30, marginBottom:30, alignItems: 'center'}}
source={{uri:'https://abs.twimg.com/icons/apple-touch-icon-192x192.png'}}/>
    <Text style={{fontSize: 30, color: '#55ACEE', textAlign: 'center'}}>
    Home Page
    </Text>
    
    </View>
    </View>
    
      );
  }
  static navigationOptions = {
    drawerLabel: 'Rishab Jain',
    drawerIcon: ()=> (
      <Image 
style={{flex: 1,width: 50, height: 50, borderRadius: 100, marginTop:30, marginBottom: 30,alignItems: 'center'}}
source={{uri:'https://qph.ec.quoracdn.net/main-thumb-106720517-200-kenemtfjcvnmelsgvldvxfywrheijala.jpeg'}}/>
    ),
  };

 
}

const DrawerExample = DrawerNavigator(
  
{
  Home: {
    screen: MyHomeScreen,
  },
  Profile: {
    path: '/',
    screen: first,
  },
  Lists: {
    path: '/sent',
    screen: second,
  },
  
  Moments: {
    path: '/',
    screen: MainScreenNavigator,
  },
  
  Highlights: {
    path: '/',
    screen: four,
  },
  
  Settings : {
    path: '/',
    screen: five,
  },
  
  Help : {
    path: '/',
    screen: six,
  },
},
{
    //initialRouteName: 'Profile',
    drawerPosition: 'left'

}

  );

//export default MainScreenNavigator;
export default DrawerExample;

